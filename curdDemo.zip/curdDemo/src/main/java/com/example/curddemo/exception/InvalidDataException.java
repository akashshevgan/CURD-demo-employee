package com.example.curddemo.exception;

public class InvalidDataException  extends Exception{

    public InvalidDataException(String msg) {
        super(msg);
    }
}

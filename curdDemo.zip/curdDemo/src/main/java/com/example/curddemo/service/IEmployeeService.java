package com.example.curddemo.service;

import com.example.curddemo.entity.Employee;
import com.example.curddemo.exception.DataNotFoundException;
import com.example.curddemo.exception.InvalidDataException;
import com.example.curddemo.exception.PersistenceException;

import java.util.List;


public interface IEmployeeService {
    public Employee addEmployee(Employee employee);
    public Employee findByEmployeeId(String id) throws DataNotFoundException, InvalidDataException;
    public List<Employee> findAllEmployee() throws  DataNotFoundException;
    public String deleteEmployee(String id) throws InvalidDataException, DataNotFoundException, PersistenceException;
    public Employee updateEmployee(String id, Employee employee) throws DataNotFoundException,InvalidDataException,PersistenceException;
}

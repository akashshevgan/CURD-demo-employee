package com.example.curddemo.repository;

import com.example.curddemo.entity.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface EmployeeRepository extends MongoRepository<Employee,Integer> {
    public Employee findByIdAndActive(String id, boolean b);
    public List<Employee> findByActive(boolean active);
    public void deleteById(String id);

}
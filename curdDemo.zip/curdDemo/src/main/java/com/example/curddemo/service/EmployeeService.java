package com.example.curddemo.service;

import com.example.curddemo.entity.Employee;
import com.example.curddemo.exception.DataNotFoundException;
import com.example.curddemo.exception.InvalidDataException;
import com.example.curddemo.exception.PersistenceException;
import com.example.curddemo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import static com.example.curddemo.constant.Message.*;
@Service
public class EmployeeService implements IEmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Override
    public Employee addEmployee(Employee employee
    ) {
        return employeeRepository.save(employee);
    }
    public List<Employee> saveEmployees(List<Employee> employee) {
        return employeeRepository.saveAll(employee);
    }
    @Override
    public Employee findByEmployeeId(String id) throws DataNotFoundException, InvalidDataException {
        if (id == null) {
            throw new InvalidDataException(INVALID_DATA);
        }
        Employee employee = employeeRepository.findByIdAndActive(id, true);
        if (employee == null) {
            throw new DataNotFoundException(RECORD_NOT_FOUND);
        }
        return employee;
    }
    @Override
    public List<Employee> findAllEmployee() throws DataNotFoundException {
        List<Employee> employee = employeeRepository.findByActive(true);
        if (employee != null && !employee.isEmpty()) {
            return employee;
        }
        throw new DataNotFoundException(EMPLOYEE_NOT_FOUND);
    }
    @Override
    public String deleteEmployee(String id) throws DataNotFoundException {
        Employee employee = employeeRepository.findByIdAndActive(id, true);
        if (employee == null) {
            throw new DataNotFoundException(RECORD_NOT_FOUND);
        }
        employeeRepository.deleteById(id);
        return("data deleted");
    }

    @Override
    public Employee updateEmployee(String id, Employee employee) throws DataNotFoundException, InvalidDataException{
        if (id == null) {
            throw new InvalidDataException(INVALID_DATA);
        }
        Employee employee1 = employeeRepository.findByIdAndActive(id, true);
        if (employee1 == null) {
            throw new DataNotFoundException(RECORD_NOT_FOUND);
        }
        return employeeRepository.save(employee);
    }

}

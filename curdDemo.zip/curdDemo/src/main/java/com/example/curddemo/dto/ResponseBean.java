package com.example.curddemo.dto;


import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class ResponseBean<T> {

    private boolean success;
    private String message;
    private T data;

    public ResponseBean(boolean success, String message) {
        super();
        this.success = success;
        this.message = message;
    }

    public ResponseBean(String message, T data) {
        super();
        this.success = (data != null);
        this.message = message;
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }

}

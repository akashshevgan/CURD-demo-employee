package com.example.curddemo.constant;

public interface Message {

    public final static String INVALID_DATA = "Invalid Data, Please enter valid data!";
    public final static String RECORD_NOT_FOUND = "Record not found!";
    public final static String All_EMPLOYEE_FOUND = "Employee details retrive successfully!";
    public final static String EMPLOYEE_NOT_FOUND = "Data not found!";
    public final static String RECORD_FOUND = "Record fetched successfully!";
    public static final String RECORD_DELETED = "Record deleted successfully";
    public static final String RECORD_UPDATED = "Record updated successfully";
}

package com.example.curddemo.exception;

public class PersistenceException extends Exception {

    public PersistenceException(String msg) {
        super(msg);
    }

}
package com.example.curddemo.controller;

import com.example.curddemo.dto.ResponseBean;
import com.example.curddemo.entity.Employee;
import com.example.curddemo.exception.DataNotFoundException;
import com.example.curddemo.exception.InvalidDataException;
import com.example.curddemo.exception.PersistenceException;
import com.example.curddemo.service.EmployeeService;
import com.example.curddemo.service.IEmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Collection;
import java.util.List;

import static com.example.curddemo.constant.Message.*;

@RestController
@RequestMapping("/api")
public class EmployeeController {

    @Autowired
    private IEmployeeService employeeSvc;

    @PostMapping("/addEmp")
    public Employee addEmployee(@RequestBody Employee employee) {
        return employeeSvc.addEmployee(employee);
    }
    @GetMapping("/employee")
    public ResponseEntity<ResponseBean<Collection<Employee>>> findAll() throws DataNotFoundException {
        return ResponseEntity.ok(new ResponseBean<Collection<Employee>>("employee " + RECORD_FOUND, employeeSvc.findAllEmployee()));
    }

    @GetMapping("/employe/{id}")
    public ResponseEntity<ResponseBean<Employee>> findByEmployeeId(@PathVariable("id") String id) throws DataNotFoundException, InvalidDataException {
        return ResponseEntity.ok(new ResponseBean<Employee>(All_EMPLOYEE_FOUND, employeeSvc.findByEmployeeId(id)));
    }

    @DeleteMapping("/employee/{id}")
    public ResponseEntity<ResponseBean<String>> deleteCustomer(@PathVariable("id") String id) throws DataNotFoundException, InvalidDataException, PersistenceException {
        return ResponseEntity.ok(new ResponseBean<String>(RECORD_DELETED, employeeSvc.deleteEmployee(id)));
    }
    @PutMapping("/employee/{id}")
    public ResponseEntity<ResponseBean<Employee>> updateEmployee(@PathVariable("id") String id,  @RequestBody Employee employee) throws  InvalidDataException, PersistenceException, DataNotFoundException {
        return ResponseEntity.ok(new ResponseBean<Employee>(RECORD_UPDATED, employeeSvc.updateEmployee(id, employee)));
    }
}
